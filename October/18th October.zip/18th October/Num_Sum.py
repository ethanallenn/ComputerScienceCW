num = int(input("Enter a number: "))
sum = 0
i = 1

while i <= num:
    sum += i
    i += 1

print("The sum of all numbers from 1 to", num, "is", sum)
